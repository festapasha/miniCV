﻿param (
    [string]$mail,
    [string]$database
)


& $mail -database $database