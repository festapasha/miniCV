﻿param (
    [string]$database
)

Get-Content $database | ForEach-Object {
    $parts = $_ -split ","
    $name = $parts[0]
    $address = $parts[1]
    $time = $parts[2]

    Write-Host "Dear $name!"
    Write-Host "You are invited to meet Santa Claus in $address at $time."
    Write-Host "See you soon!"
    Write-Host ""
    Write-Host ""
}