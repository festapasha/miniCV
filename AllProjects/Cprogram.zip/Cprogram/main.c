#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dice.h"


struct Armor {
    char id[20];
    int armor_class;
};


struct AttackType {
    char id[20];
    int dice_count;
    DiceType dice_type;
    int damage_bonus;
};


struct Creature {
    char id[20];
    int hp;
    int attack_bonus;
    struct Armor armor;
    struct AttackType attack_type;
};


struct Armor parse_armor(FILE *fp) {
    struct Armor a;
    fscanf(fp, "%s %d", a.id, &a.armor_class);
    return a;
}


struct AttackType parse_attack_type(FILE *fp) {
    struct AttackType at;
    char dice_str[10];
    fscanf(fp, "%s %d %s %d", at.id, &at.dice_count, dice_str, &at.damage_bonus);
    if (strcmp(dice_str, "D4") == 0) at.dice_type = D4;
    else if (strcmp(dice_str, "D6") == 0) at.dice_type = D6;
    else if (strcmp(dice_str, "D8") == 0) at.dice_type = D8;
    else if (strcmp(dice_str, "D10") == 0) at.dice_type = D10;
    else if (strcmp(dice_str, "D12") == 0) at.dice_type = D12;
    else if (strcmp(dice_str, "D20") == 0) at.dice_type = D20;
    else if (strcmp(dice_str, "D100") == 0) at.dice_type = D100;
    else {
        fprintf(stderr, "Unknown dice type: %s\n", dice_str);
        exit(1);
    }

    return at;
}


struct Creature parse_creature(
    FILE *fp,
    struct Armor armors[], int armor_count,
    struct AttackType attack_types[], int attack_type_count
) {
    struct Creature c;
    char armor_id[20], attack_id[20];

    fscanf(fp, "%s %d %d %s %s", c.id, &c.hp, &c.attack_bonus, armor_id, attack_id);
     int found = 0;
    for (int i = 0; i < armor_count; i++) {
        if (strcmp(armor_id, armors[i].id) == 0) {
            c.armor = armors[i];
            found = 1;
            break;
        }
    }
    if (!found) {
        fprintf(stderr, "Unknown armor: %s\n", armor_id);
        exit(1);
    }
    found = 0;
    for (int i = 0; i < attack_type_count; i++) {
        if (strcmp(attack_id, attack_types[i].id) == 0) {
            c.attack_type = attack_types[i];
            found = 1;
            break;
        }
    }
    if (!found) {
        fprintf(stderr, "Unknown attack type: %s\n", attack_id);
        exit(1);
    }

    return c;
}


struct Creature *fight(struct Creature *c1, struct Creature *c2) {
    struct Creature *attacker = c1;
    struct Creature *defender = c2;

    while (1) {
        
        int attack_roll = roll(D20, 1, attacker->attack_bonus);

        if (attack_roll >= defender->armor.armor_class) {
            
            int damage = roll(attacker->attack_type.dice_type,
                              attacker->attack_type.dice_count,
                              attacker->attack_type.damage_bonus);
            defender->hp -= damage;

            if (defender->hp <= 0) {
                return attacker; 
            }
        }
        struct Creature *tmp = attacker;
        attacker = defender;
        defender = tmp;
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Error opening file");
        return 1;
    }

   
    int armor_count;
    fscanf(fp, "%d", &armor_count);
    struct Armor *armors = malloc(sizeof(struct Armor) * armor_count);
    for (int i = 0; i < armor_count; i++) {
        armors[i] = parse_armor(fp);
    }

    
    int attack_count;
    fscanf(fp, "%d", &attack_count);
    struct AttackType *attacks = malloc(sizeof(struct AttackType) * attack_count);
    for (int i = 0; i < attack_count; i++) {
        attacks[i] = parse_attack_type(fp);
    }

    
    int creature_count;
    fscanf(fp, "%d", &creature_count);
    struct Creature *creatures = malloc(sizeof(struct Creature) * creature_count);
    for (int i = 0; i < creature_count; i++) {
        creatures[i] = parse_creature(fp, armors, armor_count, attacks, attack_count);
    }

    fclose(fp);

    for (int i = 0; i < creature_count; i += 2) {
        struct Creature *winner = fight(&creatures[i], &creatures[i + 1]);
        printf("%c", winner->id[0]);
    }
    printf("\n");

    
    free(armors);
    free(attacks);
    free(creatures);

    return 0;
}
