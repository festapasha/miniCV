using System;

class Program
{
    static void Main(string[] args)
    {
        int n;
        int[] ttime;
        bool exists;

        Console.Write("n = ");
        int.TryParse(Console.ReadLine(), out n);

        ttime = new int[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write($"{i + 1}. traveling time = ");
            int.TryParse(Console.ReadLine(), out ttime[i]);
        }

        int wind = 1; // start from the second train
        while (wind < n && !(ttime[wind] < ttime[wind - 1]))
        {
            wind++;
        }

        exists = (wind < n);

        if (exists)
        {
            Console.WriteLine($"The {wind + 1}. train is faster than the previous one");
        }
        else
        {
            Console.WriteLine("There is no such train");
        }
    }
}
