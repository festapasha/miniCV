using System;

class Program
{
    static void Main(string[] args)
    {
        int n = Convert.ToInt32(Console.ReadLine());
         int[,] data = new int[n, 2];
         int cnt = 0;

          for (int i = 0; i < n; i++)
        {
            string[] parts = Console.ReadLine().Split();
            data[i, 0] = Convert.ToInt32(parts[0]);
            data[i, 1] = Convert.ToInt32(parts[1]);

            if(!isUnique(data, i))
            {
                cnt++;
            }
            
        }
        Console.WriteLine(cnt);

    }
    public static bool isUnique(int[,] data, int index) {
            int currentAge = data[index, 0];

            for(int j = 0; j<index; j++)
        {
            if(data[j,0] == currentAge)
            {
                return false;
            }

        }
        return true;
        }

}
