using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the number of students:  ");
        int n = int.Parse(Console.ReadLine());

        int[] meters = new int[n];
        int[] cm = new int[n];

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Student {i + 1}");

            Console.Write("Meters: ");
            meters[i] = int.Parse(Console.ReadLine());

            Console.Write("Centimeters: ");
            cm[i] = int.Parse(Console.ReadLine());
        }

        int tallestIndex = 0;
        int maxHeight = meters[0] * 100 + cm[0];

        for (int i = 1; i < n; i++)
        {
            int totalHeight = meters[i] * 100 + cm[i];

            if (totalHeight > maxHeight)
            {
                maxHeight = totalHeight;
                tallestIndex = i;
            }
        }

        int finalMeters = maxHeight / 100;
        int finalCentimeters = maxHeight % 100;

        Console.WriteLine();
        Console.WriteLine($"The tallest student is #{tallestIndex + 1}");
        Console.WriteLine($"Height: {finalMeters} m {finalCentimeters} cm");
    }
}
