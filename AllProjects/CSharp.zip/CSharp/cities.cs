using System;

class Program
{
    static void Main()
    {
        
        Console.WriteLine("Enter the number of cities: ");
        int citiesN = Convert.ToInt32(Console.ReadLine());
        string[] cities = new string[citiesN];
        int longestDistance = int.MinValue;
        int longestIndex = 0;
        int priceIndex = 0;

        int[] distance = new int[citiesN];
        int[] price = new int[citiesN];
        for (int i = 0; i < citiesN; i++){
            Console.WriteLine($"Enter the name of city {i + 1}: ");
            cities[i] = Console.ReadLine();

             Console.WriteLine($"Enter the distance of city {i + 1}: ");
            distance[i] = Convert.ToInt32(Console.ReadLine());

             Console.WriteLine($"Enter the price of city {i + 1}: ");
            price[i] = Convert.ToInt32(Console.ReadLine());

            if(distance[i] > longestDistance){
                longestDistance = distance[i];
                longestIndex = i;
                priceIndex = i;
            }


        }
        Console.WriteLine($"The longest trip was {cities[longestIndex]} with the distance of {longestDistance} with the price {price[priceIndex]}");

    }
}