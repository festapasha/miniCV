using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("How many days did you log the number of spells for: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] numberOfSpells = new int[n];
        int count = 0;

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter the numer of spells in day {i + 1}: ");
            numberOfSpells[i] = Convert.ToInt32(Console.ReadLine());
            int previousDaySpells = (i == 0) ? 0 : numberOfSpells[i - 1];
            if (numberOfSpells[i] > previousDaySpells)
            {
                count++;
            }
        }
        Console.WriteLine($"Number of increased failed spells: {count}");
    }
}
