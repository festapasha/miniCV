using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("how many numbers do you want to compare?:  ");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] numbers = new int[n];
        int smallestNumber = int.MaxValue;
        int biggestNumber = int.MinValue;

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter number {i + 1}: ");
            numbers[i] = Convert.ToInt32(Console.ReadLine());

            if (numbers[i] < smallestNumber)
            {
                smallestNumber = numbers[i];
            }

            if (numbers[i] > biggestNumber)
            {
                biggestNumber = numbers[i];
            }
        }

        Console.WriteLine($"The smallest number is: {smallestNumber}");
        Console.WriteLine($"The biggest number is: {biggestNumber}");

        

        
    }
}