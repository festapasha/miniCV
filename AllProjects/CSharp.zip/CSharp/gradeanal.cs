using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("how many students do you want to analyze");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] num = new int[n];
        string[] names = new string[n];
        string highestStudent = "";
        int sum = 0;
        double average = 0;
        int highestGrade = int.MinValue;
        int count = 0;

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter the name of student {i +1}: ");
            names[i] = Console.ReadLine();
            Console.WriteLine($"Enter the grades of student {i + 1}: ");
            num[i] = Convert.ToInt32(Console.ReadLine());

            sum = sum + num[i];

            double average = (double)sum / n;

            if (num[i] > highestGrade)
            {
                highestGrade = num[i];
                highestStudent = names[i];
            }
            if(num[i] >= 50)
            {
                count++;
            }
        }
        Console.WriteLine($"The average grade is: {average}");
        Console.WriteLine($"The highest grade is: {highestGrade} and the name of the student is: {highestStudent}");
        Console.WriteLine($"The nr of students who passed is: {count}");
    }
}
