using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("How many words do you want to enter: ");
        int n = Convert.ToInt32(Console.ReadLine());
        string[] words = new string[n];
        string wantedWord;
        int times = 0;

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter word {i + 1}:  ");
            words[i] = Console.ReadLine();
        }

        Console.WriteLine("Which word do you want to search for? ");
        wantedWord = Console.ReadLine();

        for (int i = 0; i < n; i++)
        {
            if (wantedWord == words[i])
            {
                times++;
            }
        }
        Console.WriteLine($"The word {wantedWord} appears {times} times");

    }

    
}
