using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Hello, World!\n");

        for (int i = 0; i <= 10; i++)
        {
            for (int j = 0; j <= 10; j++)
            {
                int result = i * j;
                Console.Write(result + "\t");
            }
            Console.WriteLine();
        }
    }
}