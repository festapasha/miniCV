using System;

class Program
{
    static void Main(string[] args)
    {
        int n = Convert.ToInt32(Console.ReadLine());

        int[] ages = new int[n];
        int[] salary = new int[n];
        int prevAge = 0;

        int cnt = 0;

        
        for(int i = 0; i < n; i++)
        {
            string[] input = Console.ReadLine().Split();
            ages[i] = Convert.ToInt32(input[0]);

            bool found = false;

            for (int j = 0; j < i; j++)
            {
                if (ages[i] == ages[j])
                {
                    found = true;
                    break;
                }
            }

            if (found == false)
            {
                cnt++;
            }

        }

        
        Console.WriteLine(cnt);


    }
}
