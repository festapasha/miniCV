using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("how many students are there:");
        int n = Convert.ToInt32(Console.ReadLine());

        string[] students = new string[n];
        int[] grades = new int[n];
        int sum = 0;
        int biggest = 0;
        string bestStudent = "";

        Console.WriteLine("enter the students names and grades");
        
        for(int i = 0; i < n; i++)
        {
        string input = Console.ReadLine();
        students[i] = input.Split()[0];
        grades[i] = Convert.ToInt32(input.Split()[1]);

        sum += grades[i];
        if(grades[i] > biggest)
            {
                biggest = grades[i];
                bestStudent = students[i];
            }

        }
        Console.WriteLine($"The class average is: {(double)sum/n}");
        Console.WriteLine($"The highest grade is is: {biggest}");
        Console.WriteLine($"The student with the highest grade is: {bestStudent}");
    }
}
