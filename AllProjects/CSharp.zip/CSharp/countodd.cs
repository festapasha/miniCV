using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("how many nr enter: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] num = new int[n];
        int sum = 0;

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter number {i + 1}: ");
            num[i] = Convert.ToInt32(Console.ReadLine());

            if (num[i] % 2 == 1)
            {
                sum = sum + num[i];
            }
        }

        Console.Write($"The sum of odd nr is: {sum}");
        
    }
}