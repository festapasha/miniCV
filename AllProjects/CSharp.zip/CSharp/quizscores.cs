using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("How many students are in the class");
        int n = Convert.ToInt32(Console.ReadLine());
        string[] students = new string[n];
        int[] score = new int[n];
        int highestScore = int.MinValue;
        int highestIndex = 0;
        int lowestScore = int.MaxValue;
        int lowestIndex = 0;
        int sum = 0;
        double average;

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter name of student {i + 1}: ");
            students[i] = Console.ReadLine();
            Console.WriteLine($"Enter score of student {i + 1}: ");
            score[i] = Convert.ToInt32(Console.ReadLine());

            if (score[i] < lowestScore)
            {
                lowestScore = score[i];
                lowestIndex = i;
            }
            if (score[i] > highestScore)
            {
                highestScore = score[i];
                highestIndex = i;
            }
        }
        for (int i = 0; i < n; i++)
        {
            sum = sum + score[i];
        }
        average = (double)sum / n;

        Console.WriteLine($"Highest Score: {highestScore} from {students[highestIndex]}");
        Console.WriteLine($"Lowest Score: {lowestScore} from {students[lowestIndex]}");
        Console.WriteLine($"Average score on the quiz is: {average}");
    }
}