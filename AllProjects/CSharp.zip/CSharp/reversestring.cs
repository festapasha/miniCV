using System;

class Program
{
    static void Main(string[] args)
    {
        Random rnd = new Random();
        int number = rnd.Next(101);
        bool guessed = false;

        Console.WriteLine("Guess a number between 0 and 100:");

        while (!guessed)
        {
            int guess = Convert.ToInt32(Console.ReadLine());

            if (guess == number)
            {
                guessed = true;
                Console.WriteLine($"Correct! The number was {number}");
            }
            else if (guess > number)
            {
                Console.WriteLine("Too high, guess lower.");
            }
            else
            {
                Console.WriteLine("Too low, guess higher.");
            }
        }
    }
}
