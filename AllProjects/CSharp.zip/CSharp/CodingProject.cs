using System;

class Program
{
    static void Main(string[] args)
    {
        int n = Convert.ToInt32(Console.ReadLine());
        int[] age = new int[n];
        int[] salary = new int[n];
        int duplicateCount = 0;

        for (int i = 0; i < n; i++)
        {
            
            string[] parts = Console.ReadLine().Split();
            age[i] = Convert.ToInt32(parts[0]);
            salary[i] = Convert.ToInt32(parts[1]);

            
            for (int j = 0; j < i; j++)
            {
                if (age[i] == age[j])
                {
                    duplicateCount++;
                    break; 
                }
            }

            Console.WriteLine($"After entry {i + 1}, duplicates found so far: {duplicateCount}");
        }

        Console.WriteLine($"Total duplicate ages: {duplicateCount}");
    }
}
