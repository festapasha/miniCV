using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("How many numbers do you want to enter");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] numbers = new int[n];
        int count = 0;

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter number {i + 1}");
            numbers[i] = Convert.ToInt32(Console.ReadLine());

            if (numbers[i] < 0)
            {
                count++;
            }

        }

        Console.Write($"There were: {count} negative numbers");

        
        
    }
}