using System;

class Program
{
    static void Main(string[] args)
    {
        
        Console.WriteLine("how many numbers do you want to compare?:  ");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] numbers = new int[n];
        int sum = 0;
        double average;

        

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Enter number {i + 1}: ");
            numbers[i] = Convert.ToInt32(Console.ReadLine());
        }

        for (int i = 0; i < n; i++)
        {
            sum = sum + numbers[i];
        }
        average = (double)sum / n;

        Console.WriteLine($"The total sum of the numbers is: {sum} and the average of the numbers is: {average}");


    }
}