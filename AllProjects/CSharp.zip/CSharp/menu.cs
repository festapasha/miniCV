using System;

class Program
{
    static void Main(string[] args)
    {
        int[] input = null;
        int[] output = null;
        bool running = true;
        Random rand = new Random();

        while (running)
        {
            Console.WriteLine("\nChoose an option:");
            Console.WriteLine("a - Give an integer sequence");
            Console.WriteLine("b - Generate a random int sequence");
            Console.WriteLine("c - Collect the even numbers");
            Console.WriteLine("d - Write out the input sequence");
            Console.WriteLine("e - Write out the output (even numbers)");
            Console.WriteLine("f - Finish the program");
            Console.Write("Your option? ");

            string choice = Console.ReadLine();

            if (choice == "a")
            {
                input = ReadInput();
            }
            else if (choice == "b")
            {
                input = GenerateRandomInput();
            }
            else if (choice == "c")
            {
                if (input != null)
                    output = CollectEvenNumbers(input);
                else
                    Console.WriteLine("Please enter or generate input first!");
            }
            else if (choice == "d")
            {
                if (input != null)
                    PrintSequence(input, "Input sequence");
                else
                    Console.WriteLine("No input sequence to display.");
            }
            else if (choice == "e")
            {
                if (output != null)
                    PrintSequence(output, "Output (even numbers)");
                else
                    Console.WriteLine("No output sequence to display.");
            }
            else if (choice == "f")
            {
                running = false;
                Console.WriteLine("Program finished.");
            }
            else
            {
                Console.WriteLine("Invalid option. Try again.");
            }
        }
    }

    static int[] ReadInput()
    {
        Console.Write("How many numbers? ");
        int n = int.Parse(Console.ReadLine());
        int[] arr = new int[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Enter number {i + 1}: ");
            arr[i] = int.Parse(Console.ReadLine());
        }

        return arr;
    }

    static int[] GenerateRandomInput()
    {
        Console.Write("How many numbers? ");
        int n = int.Parse(Console.ReadLine());
        int[] arr = new int[n];
        Random rand = new Random();

        for (int i = 0; i < n; i++)
            arr[i] = rand.Next(0, 100);

        return arr;
    }

    static int[] CollectEvenNumbers(int[] arr)
    {
        int count = 0;
        foreach (int x in arr)
            if (x % 2 == 0) count++;

        int[] even = new int[count];
        int index = 0;
        foreach (int x in arr)
            if (x % 2 == 0) even[index++] = x;

        return even;
    }

    static void PrintSequence(int[] arr, string name)
    {
        Console.WriteLine($"{name}: {string.Join(", ", arr)}");
    }
}
