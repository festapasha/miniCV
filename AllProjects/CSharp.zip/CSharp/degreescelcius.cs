using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of degrees Celsius:");
        double C = Convert.ToDouble(Console.ReadLine());
        double F = C * (9.0 / 5.0) + 32;
        Console.WriteLine($"Fahrenheit: {F}");
    }
}
