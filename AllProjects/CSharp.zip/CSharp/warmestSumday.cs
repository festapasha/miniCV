using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("How many days of temp measurements are there? ");
        int n = Convert.ToInt32(Console.ReadLine());
        int[] temp = new int[n];

        if (n < 7)
        {
            Console.WriteLine("There is no Sunday logged!");
            return; 
        }

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Enter temperature for day {i + 1}: ");
            temp[i] = Convert.ToInt32(Console.ReadLine());
        }

        int warmestSunday = int.MinValue;

        for (int i = 6; i < n; i += 7) 
        {
            if (temp[i] > warmestSunday)
            {
                warmestSunday = temp[i];
            }
        }

        Console.WriteLine($"The warmest Sunday is {warmestSunday}");
    }
}
