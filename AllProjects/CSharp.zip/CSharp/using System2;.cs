using System;

class Program
{
    static void Main()
    {
        

        Console.WriteLine("Enter three words seperated by spaces");
        string input = Console.ReadLine();
        string wordOne = input.Split(" ")[0];
        string wordTwo = input.Split(" ")[1];
        string wordThree = input.Split(" ")[2];

        if(wordOne.Length>= wordTwo.Length && wordOne.Length>= wordThree.Length)
        {

            Console.WriteLine($"The longest word is: {wordOne}");
        }
        else if(wordTwo.Length>= wordOne.Length && wordTwo.Length>= wordThree.Length){

             Console.WriteLine($"The longest word is: {wordTwo}");
        }
        else{

             Console.WriteLine($"The longest word is: {wordThree}");
        }
        
    }
}