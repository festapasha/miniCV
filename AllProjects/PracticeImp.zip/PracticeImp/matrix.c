#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"


Matrix* init_matrix(int n, int m) {
    if (n < 1 || m < 1) {
        fprintf(stderr, "Invalid matrix dimensions: %d x %d\n", n, m);
        return NULL;
    }

    Matrix* mat = (Matrix*)malloc(sizeof(Matrix));
    if (!mat) {
        fprintf(stderr, "Failed to allocate memory for Matrix struct\n");
        return NULL;
    }

    mat->rows = n;
    mat->cols = m;
    mat->data = (int*)malloc(n * m * sizeof(int));

    if (!mat->data) {
        fprintf(stderr, "Failed to allocate memory for matrix data\n");
        free(mat);
        return NULL;
    }

   
    for (int i = 0; i < n * m; i++) {
        mat->data[i] = 0;
    }

    return mat;
}

void free_matrix(Matrix* mat) {
    if (mat == NULL)
        return;

    free(mat->data);
    free(mat);
}


int* get_element(Matrix* mat, int row, int col) {
    if (!mat) {
        fprintf(stderr, "Matrix is NULL\n");
        return NULL;
    }
    if (row < 0 || row >= mat->rows || col < 0 || col >= mat->cols) {
        fprintf(stderr, "Index out of bounds: row=%d, col=%d\n", row, col);
        return NULL;
    }

    return &(mat->data[row * mat->cols + col]);
}


Matrix* multiply_matrices(Matrix* a, Matrix* b) {
    if (!a || !b) {
        fprintf(stderr, "One or both matrices are NULL\n");
        return NULL;
    }

    if (a->cols != b->rows) {
        fprintf(stderr, "Incompatible matrix dimensions for multiplication\n");
        return NULL;
    }

    Matrix* result = init_matrix(a->rows, b->cols);
    if (!result) {
        fprintf(stderr, "Failed to allocate result matrix\n");
        return NULL;
    }

    for (int i = 0; i < a->rows; i++) {
        for (int j = 0; j < b->cols; j++) {
            int sum = 0;
            for (int k = 0; k < a->cols; k++) {
                sum += a->data[i * a->cols + k] * b->data[k * b->cols + j];
            }
            *get_element(result, i, j) = sum;
        }
    }

    return result;
}
