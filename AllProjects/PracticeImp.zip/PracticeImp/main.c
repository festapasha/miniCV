#include <stdio.h>
#include "matrix.h"

int main() {
    //main.c is just for me to make it easier to run 
    //and also to practice more code withthis program
    Matrix* A = init_matrix(2, 3);
    if (A == NULL) return 1;

    *get_element(A, 0, 0) = 1;
    *get_element(A, 0, 1) = 2;
    *get_element(A, 0, 2) = 3;
    *get_element(A, 1, 0) = 4;
    *get_element(A, 1, 1) = 5;
    *get_element(A, 1, 2) = 6;

    
    Matrix* B = init_matrix(3, 2);
    if (B == NULL) {
        free_matrix(A);
        return 1;
    }

    *get_element(B, 0, 0) = 7;
    *get_element(B, 0, 1) = 8;
    *get_element(B, 1, 0) = 9;
    *get_element(B, 1, 1) = 10;
    *get_element(B, 2, 0) = 11;
    *get_element(B, 2, 1) = 12;

   
    Matrix* C = multiply_matrices(A, B);
    if (C != NULL) {
        printf("Result Matrix (2x2):\n");
        for (int i = 0; i < C->rows; i++) {
            for (int j = 0; j < C->cols; j++) {
                printf("%d ", *get_element(C, i, j));
            }
            printf("\n");
        }
    }

 
    free_matrix(A);
    free_matrix(B);
    free_matrix(C);

    return 0;
}
